"""
improcpy.

Image Processing Python
"""

__version__ = "0.1.0"
__author__ = 'Ian Hammond'
__credits__ = 'BYU CS 355'